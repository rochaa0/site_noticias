create database news;
use news;

CREATE TABLE usuario (
  cod_usu int(3) primary key auto_increment,
  nome_usu varchar(20) not null,
  email varchar(40),
  senha varchar(15) not null,
  cargo varchar(30)
);

drop table usuario
select * from usuario;

CREATE TABLE noticia(
  cod_not int(3) auto_increment,
  titulo varchar(100) not null,
  lide varchar(200) not null,
  texto text not null,
  autor varchar(30),
  dt_not date not null,
  primary key(cod_not),
  unique(cod_not)
);

select * from noticia;
drop table noticia