<?php
    include('Conexao.php');

    $titulo = $_POST['Titulo'];
    $lide = $_POST['Lide'];
    $texto = $_POST['Texto'];
    $autor = $_POST['Autor'];
    $data = $_POST['Dt_not'];
    
    $host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);

    $comando = mysqli_query($con, "INSERT INTO noticia (titulo, lide, texto, autor, dt_not) VALUES ('$titulo', '$lide', '$texto', '$autor', '$data')") or die("Erro ao cadastrar!");
    
    echo ("Cadastro realizada com sucesso!");
    echo ("<br><br>");
    echo ("<a href='index.html'>Voltar</a>");

    mysqli_close($con);
    ?>