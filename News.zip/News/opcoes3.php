<?php 
$host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);


?>
 
 <!DOCTYPE html>
 <html lang="en">
 <head>
	 <meta charset="UTF-8">
	 <meta http-equiv="X-UA-Compatible" content="IE=edge">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <title>Opções</title>
 </head>
 <body>

 <h3>Cadastro Efetuado com sucesso !!</h3> <br>
<a href="index.html">Início</a> <br>
<a href="cadastrar.php">Cadastrar Notícia</a> <br>
<a href="exibe.php">Visualizar Cadastros</a> <br>
<a href="exibenot.php">Visualizar Notícias</a> <br>
	 
 </body>
 </html>