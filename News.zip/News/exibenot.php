<meta charset="utf-8"> 
<?php
	$host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);
	$res = mysqli_query($con,"select * from noticia"); 
	
echo "<table border=3px><tr><td>Codigo da Notícia</td><td>Título da Notiícia</td><td>Lide</td><td>Texto</td><td>Autor</td><td>Data</td></tr>";

while($escrever=mysqli_fetch_array($res)){

echo "</td><td>" . $escrever['cod_not'] . "</td><td>" . $escrever['titulo'] . "</td><td>" . $escrever['lide'] ."</td><td>" .$escrever['texto'] . "</td><td>".$escrever['autor'] ."</td><td>".$escrever['dt_not'];
}

echo "</table>"; 

echo "</br></br>";

mysqli_close($con);
?>




	  