<?php
$host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
    $mysqli = new mysqli($host, $user, $pass, $base);

    if($mysqli->error) {
        die("Falha ao conectar ao banco de dados: " . $mysqli->error);
    }