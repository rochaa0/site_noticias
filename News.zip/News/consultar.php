<?php
$host  = "localhost:3307";
$user  = "root";
$pass  = "root";
$base  = "news";
$con   = mysqli_connect($host, $user, $pass, $base);
$res = mysqli_query($con, "select * from usuario");

mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Consultar</title>
        <link rel="stylesheet" href="css/nav.css">
    </head>
    <body>
        <nav>
            <a href="index.html">
                <div class="logo">
                    <span>INFO</span> News
                </div>
            </a>

            <div class="options">
                <a href="cadastrar.php">Cadastrar Notícia</a>
                <a href="consultar.php">Consultar</a>
                <?php
                while ($escrever = mysqli_fetch_array($res)) {
                    echo "<a href='#'>" . $escrever['nome_usu'] . "</a>";
                }
                ?>
                </a>
            </div>
        </nav>
        <div class="">
            <form method="POST" action="busca.php">
                <label>Titulo da notícia</label>
                    <input type="text" name="titulo" placeholder="Digite o titulo da notícia">
                    <br>
                <input type="submit" value="Procurar">
            </form>    
        </div>
    </body>
</html>