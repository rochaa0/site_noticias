<?php
    $host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);

    $pesquisar = $_POST['titulo'];

    $result_titulo = "SELECT titulo FROM noticia WHERE titulo LIKE '%$pesquisar%'";
    $result_texto = "SELECT texto FROM noticia WHERE titulo LIKE '%$pesquisar%'";
    $result_autor = "SELECT autor FROM noticia WHERE titulo LIKE '%$pesquisar%'";

    $resultado_titulo = mysqli_query($con, $result_titulo);
    $resultado_texto = mysqli_query($con, $result_texto);
    $resultado_autor = mysqli_query($con, $result_autor);

    while ($rows_titulo = mysqli_fetch_array($resultado_titulo)){
        echo "Titulo da Noticia: ".$rows_titulo['titulo']."<br><br>";
    }

    while ($rows_texto = mysqli_fetch_array($resultado_texto)){
        echo "Texto da Noticia: ".$rows_texto['texto']."<br><br>";
    }

    while ($rows_autor = mysqli_fetch_array($resultado_autor)){
        echo "Nome do autor da Noticia: ".$rows_autor['autor']."<br><br>";
    }
?>