<meta charset="utf-8"> 
<?php
	$host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);
	$res = mysqli_query($con,"select * from usuario"); 
	
echo "<table border=3px><tr><td>Codigo do Usuário</td><td>Nome do Usuário</td><td>Email do Usuário</td><td>Senha</td><td>Cargo</td></tr>";

while($escrever=mysqli_fetch_array($res)){

echo "</td><td>" . $escrever['cod_usu'] . "</td><td>" . $escrever['nome_usu'] . "</td><td>" . $escrever['email'] ."</td><td>" .$escrever['senha'] . "</td><td>".$escrever['cargo'] ."</td></tr>";
}

echo "</table>"; 

echo "</br></br>";

mysqli_close($con);
?>




	  