<?php
$host  = "localhost:3307";
$user  = "root";
$pass  = "root";
$base  = "news";
$con   = mysqli_connect($host, $user, $pass, $base);
$res = mysqli_query($con, "select * from usuario");

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>
    <nav>
        <a href="index.html">
            <div class="logo">
                <span>INFO</span> News
            </div>
        </a>

        <div class="options">
            <a href="cadastrar.php">Cadastrar Notícia</a>
            <a href="consultar.php">Consultar</a>
            
            </a>
        </div>
    </nav>

    <form action="cad.php" method="post">
        <div class="titulo">
            <h1>Cadastro da Notícia</h1>
        </div>
        <div class="frm">
            Titulo:
            <div class="txt">
                <input type="text" name="Titulo" maxlength="100" required>
            </div>
        </div>

        <div class="frm">
            Lide:
            <div class="txt">
                <input type="text" name="Lide" maxlength="200" required>
            </div>
        </div>

        <div class="frm">
            Texto:
            <div class="txt">
                <textarea name="Texto" required></textarea>
            </div>
        </div>

        <div class="frm">
            Autor:
            <div class="txt">
                <input type="text" maxlength="50" name="Autor" required>
            </div>
        </div>

        <div class="frm">
            Data da Notícia:
            <div class="txt">
                <input type="date" name="Dt_not" required>
            </div>
        </div>

        <div class="btn">
            <button type="submit">
                Cadastrar
                <span></span>
            </button>
        </div>
    </form>

</body>

</html>