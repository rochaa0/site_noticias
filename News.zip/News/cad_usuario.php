<?php
    include('Conexao.php');

    $nome = $_POST['nome_usu'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $cargo = $_POST['cargo'];

    $host  = "localhost:3307";
	$user  = "root";
	$pass  = "root";
    $base  = "news";
	$con   = mysqli_connect($host, $user, $pass, $base);

    $comando = mysqli_query($con, "INSERT INTO usuario (nome_usu, email, senha, cargo) VALUES ('$nome', '$email', '$senha', '$cargo')") or die("Erro ao cadastrar!");

    echo ("Cadastro realizada com sucesso!");
    echo ("<br><br>");

    $result = $mysqli->query("SELECT cargo from usuario where cargo='$cargo'");
    $result = $result->fetch_assoc();

    if(($result ['cargo']== "Jornalista") || ($result ['cargo']== "jornalista"))
 {
    header('Location: opcoes2.php');
 }

 else if(($result['cargo'] == "Leitor") || ($result['cargo'] == "leitor"))
 {
    header('Location: opcoes.php');
 }

 else if(($result['cargo'] == "Administrador") || ($result['cargo'] ==  "administrador"))
 {
    header('Location: opcoes3.php');
 }

    
?>