<?php
$host  = "localhost:3307";
$user  = "root";
$pass  = "root";
$base  = "news";
$con   = mysqli_connect($host, $user, $pass, $base);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Cadastro de Usuário</title>
</head>
<body>

<nav>
        <a href="index.html">
            <div class="logo">
                <span>INFO</span> News
            </div>
        </a>

        <div class="options">
            <!-- <a href="cadastrar.php">Cadastrar Notícia</a> -->
            <a href="consultar.php">Consultar</a>
            </a>
        </div>
    </nav>
    <form action="cad_usuario.php" method="post">
        <div class="titulo">
            <h1>Cadastro de Usuário</h1>
        </div>

        <div class="frm">
            Nome:
            <div class="txt">
                <input type="text" name="nome_usu" maxlength="100" required>
            </div>
        </div>

        <div class="frm">
            Email:
            <div class="txt">
                <input type="text" name="email" maxlength="100" required>
            </div>
        </div>

        <div class="frm">
            Senha:
            <div class="txt">
            <input autocomplete="off" name="senha" id="Senha" class="input" type="password">
            </div>
        </div>

        <div class="frm">
            Cargo:
            <div class="txt">
                <input type="text" name="cargo" maxlength="200" required>
            </div>
        </div>

        <div class="check">
        <input type="checkbox" name="check"> <p> Receber atualizações por email<p>
        </div>
       

        <div class="btn">
            <button type="submit">
                Cadastrar
                <span></span>
            </button>
        </div>
    </form>
    
</body>
</html>

