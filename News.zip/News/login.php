<?php
include('Conexao.php');

if(isset($_POST['login']) || isset($_POST['senha']) || isset($_POST['cargo'])) 
{

    if(strlen($_POST['login']) == 0) 
    {
        echo "Preencha seu login";
    } 
    else if(strlen($_POST['senha']) == 0)
     {
        echo "Preencha sua senha";
    } 
    else if(strlen($_POST['cargo']) == 0) 
    {
        echo "Preencha seu cargo";
    } 
    else 
    {

        $login = $mysqli->real_escape_string($_POST['login']);
        $senha = $mysqli->real_escape_string($_POST['senha']);
        $cargo = $mysqli->real_escape_string($_POST['cargo']);

        $sql_code = "SELECT * FROM usuario WHERE email = '$login' AND senha = '$senha' AND cargo ='$cargo'";
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            
            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

    
        } else {
            echo "Falha ao logar! Login ou senha incorretos";
        }

    
    }

     
    
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <header>
        <nav>
            <a href="index.html">
                <div class="logo">
                    <span>INFO</span> News
                </div>
            </a>

            <div class="categ-fundo-2"></div>
            <div class="categ">
                <a href="Esporte.html">Esporte</a>
                <a href="Politica.html">Política</a>
                <a href="Saude.html">Saúde</a>
                <a href="Games.html">Games</a>
                <a href="Musica.html">Música</a>
            </div>

            <div class="login">
                <a href="login.php" class="cta">
                    <span class="hover-underline-animation"> Login </span>
                    <path id="Path_10" data-name="Path 10"
                        d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z"
                        transform="translate(30)"></path>
                </a>
            </div>
        </nav>
    </header>

    <main>
        <form action="login.php" method="POST">
            <div class="info">
                <div class="input-group">
                    <div class="login">
                        <label class="label">Login</label>
                        <input autocomplete="off" name="login" id="login" class="input" type="text">
                    </div>

                    <div class="senha">
                        <label class="label">Senha</label>
                        <input autocomplete="off" name="senha" id="Senha" class="input" type="password">
                    </div>

                    <div class="login">
                        <label class="label">Cargo</label>
                        <input autocomplete="off" name="cargo" id="login" class="input" type="text">
                    </div>

                </div>

                <div class="logcad">
                    <button class="button" type="submit">Entrar</button>
                    <p>
                        ou <a href="Cad_usu.php">Cadastre-se</a>
                    </p>
                </div>
            </div>
        </form>
    </main>
</body>

</html>